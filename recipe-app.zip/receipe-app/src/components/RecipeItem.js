import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faTrash } from '@fortawesome/free-solid-svg-icons'; // Import delete icon
import './RecipeItem.css';

const RecipeItem = ({ recipe, deleteRecipe, index }) => {
  const [rating, setRating] = useState(recipe.rating);

  // Function to handle setting the rating when a star is clicked
  const handleRating = (newRating) => {
    setRating(newRating); // Update local rating
    recipe.rating = newRating; // Update recipe's rating (if persistent update is required)
  };

  return (
    <div className={`recipe-card card-${index % 4}`}>
      <div className="delete-icon" onClick={() => deleteRecipe(recipe.id)}>
        <FontAwesomeIcon icon={faTrash} />
      </div>
      <div className="recipe-content">
        <h2 className="recipe-name">{recipe.name}</h2>
        <p className="recipe-description"><b>Description:</b> {recipe.description}</p>
        <p className="recipe-category"><b>Category:</b> {recipe.category}</p>

        {/* Rating Section */}
        <div className="recipe-rating-section">
          <p><b>Rate this recipe:</b></p> {/* Text beside the stars */}
          <div className="recipe-rating">
            {[...Array(5)].map((star, i) => (
              <FontAwesomeIcon
                key={i}
                icon={faStar}
                className={i < rating ? 'star-filled' : 'star'}
                onClick={() => handleRating(i + 1)} // Set the rating to the star index + 1
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeItem;
