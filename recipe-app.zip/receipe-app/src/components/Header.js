import React from 'react';

const Header = () => {
    const headerStyle = {
         // example background color
        color: '#19E1AC',
        textAlign: 'center',
        padding: '20px',
        fontsize: '50px',
    };

    return (
        <header style={headerStyle}>
            <h1>TASTY TREASURES: EXPLORE, COOK, DELIGHT</h1>
        </header>
    );
};

export default Header;
