import React, { useState } from 'react';

const AddRecipe = ({ addRecipe }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && description && category) {
      addRecipe(name, description, category);
      setName('');
      setDescription('');
      setCategory('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-recipe-form">
      <h2>Add Your Recipe</h2>
      
      {/* Recipe Name Input */}
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Recipe name"
        className="input-field"
      />

      {/* Recipe Description Input */}
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Recipe description"
        className="input-field"
      ></textarea>

      {/* Category Dropdown */}
      <select value={category} onChange={(e) => setCategory(e.target.value)} className="input-field">
        <option value="">Select Category</option>
        <option value="Dessert">Dessert</option>
        <option value="Main Course">Main Course</option>
        <option value="Appetizer">Appetizer</option>
        <option value="Drink">Drink</option>
      </select>

      {/* Add Recipe Button */}
      <button type="submit" className="add-recipe-button">Add Recipe</button>
    </form>
  );
};

export default AddRecipe;
