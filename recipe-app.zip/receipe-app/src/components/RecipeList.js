import React from 'react';
import RecipeItem from './RecipeItem'; // Import the RecipeItem component

const RecipeList = ({ recipes, deleteRecipe }) => {
  const listStyles = {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '20px',
    marginTop: '20px',
    paddingBottom: '100px', // Space for scrolling
  };

  const emptyMessageStyles = {
    fontSize: '20px',
    color: 'red',
    textAlign: 'center',
    marginTop: '40px',
  };

  return (
    <div style={listStyles}>
      {recipes.length === 0 ? (
        <p style={emptyMessageStyles}>
          No items listed. Want to Add Some?
        </p> // Display this message when the list is empty
      ) : (
        recipes.map((recipe, index) => (
          <RecipeItem 
            key={recipe.id} 
            recipe={recipe} 
            deleteRecipe={deleteRecipe} 
            index={index} 
          />
        ))
      )}
    </div>
  );
};

export default RecipeList;
