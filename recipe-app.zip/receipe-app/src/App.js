import React, { useState } from 'react';
import RecipeList from './components/RecipeList';
import AddRecipe from './components/AddRecipe';
import Header from './components/Header';
import Footer from './components/Footer';
import './App.css';

function App() {
  const [recipes, setRecipes] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState(''); // Start with no category filter

  const addRecipe = (name, description, category) => {
    const newRecipe = {
      id: Date.now(),
      name,
      description,
      category,
      rating: 0,
    };
    setRecipes([...recipes, newRecipe]);
    setCategoryFilter(''); // Reset the filter after adding a recipe to show all
  };

  const deleteRecipe = (id) => {
    setRecipes(recipes.filter((recipe) => recipe.id !== id));
  };

  // If categoryFilter is empty, show all recipes. Otherwise, filter by category.
  const filteredRecipes = recipes.filter((recipe) => {
    return categoryFilter === '' || recipe.category === categoryFilter;
  });

  // Handle category filtering via buttons
  const handleCategoryFilter = (category) => {
    setCategoryFilter(category);
  };

  return (
    <div className="App">
      <Header />

      {/* Category Filter Buttons */}
      <div className="category-buttons">
        <button onClick={() => handleCategoryFilter('')}>All</button>
        <button onClick={() => handleCategoryFilter('Dessert')}>Dessert</button>
        <button onClick={() => handleCategoryFilter('Main Course')}>Main Course</button>
        <button onClick={() => handleCategoryFilter('Appetizer')}>Appetizer</button>
        <button onClick={() => handleCategoryFilter('Drink')}>Drink</button>
      </div>

      {/* Add Recipe Form */}
      <AddRecipe addRecipe={addRecipe} />

      {/* Recipe List */}
      <RecipeList recipes={filteredRecipes} deleteRecipe={deleteRecipe} />

      <Footer />
    </div>
  );
}

export default App;
