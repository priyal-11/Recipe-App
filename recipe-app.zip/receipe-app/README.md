We have deleted the node modules so first we have to install it. The command for installing node modules is "npm install" or "npm i".
The node modules will be installed. The we have to start the application. So for that the command is "npm start". 
The app will satrt and we willbe on the landing page of it.
We can add recipe name, description and category of it and press the add recipe button it will add the recipe. 
Add the recipe for all caterories and we can see the recipe in the card view. 
There we can see the details of the recipe and we have implementd a feature for rating the recipe.
Also on the top of add recipe we can use the buttons to filter the type of recipe. 
We have four category types for recipe. 




